import './assets/styles/variables.css'
import './utils/variables.js'
import './assets/styles/global.css'
import { createRoot } from 'react-dom/client'
import './index.css'
import './assets/styles/font.css'
import App from './App'

createRoot(document.getElementById('root')!).render(
    <App />
)
